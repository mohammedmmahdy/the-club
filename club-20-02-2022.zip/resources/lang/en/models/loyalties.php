<?php

return array (
  'singular' => 'Loyalty',
  'plural' => 'Loyalties',
  'fields' =>
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'description' => 'Description',
    'title' => 'Title',
    'brief' => 'Brief',
    'discount_value' => 'Discount Value',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
