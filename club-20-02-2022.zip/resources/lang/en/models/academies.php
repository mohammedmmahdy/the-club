<?php

return array (
  'singular' => 'Academy',
  'plural' => 'Academies',
  'fields' =>
  array (
    'id' => 'Id',
    'branch_id' => 'Branch',
    'name' => 'Name',
    'about' => 'About',
    'team' => 'Team',
    'icon' => 'Icon',
    'main_photo' => 'Main Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
