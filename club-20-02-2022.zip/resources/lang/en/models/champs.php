<?php

return array (
  'singular' => 'Champ',
  'plural' => 'Champs',
  'fields' =>
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'title' => 'Title',
    'body' => 'Body',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
