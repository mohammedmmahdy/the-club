<?php

return array (
  'singular' => 'Notification',
  'plural' => 'Notifications',
  'fields' =>
  array (
    'id' => 'ID',
    'title' => 'Title',
    'brief' => 'Brief',
    'description' => 'Description',
    'icon' => 'Icon',
    'photo' => 'Photo',
    'receiver_type' => 'Receiver Type',
    'btn_to' => 'button To',
    'created_by' => 'Created By',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
