<?php

return array (
  'singular' => 'Playground Type',
  'plural' => 'Playground Types',
  'fields' =>
  array (
    'id' => 'Id',
    'name' => 'Name',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
