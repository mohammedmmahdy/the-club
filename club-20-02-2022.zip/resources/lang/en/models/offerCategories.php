<?php

return array (
  'singular' => 'Offer Category',
  'plural' => 'Offer Categories',
  'fields' =>
  array (
    'id' => 'Id',
    'name' => 'Name',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
