<?php

return array (
  'singular' => 'النشرة الإخبارية',
  'plural' => 'النشرات الإخبارية',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'email' => 'البريد الاكتروني',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
