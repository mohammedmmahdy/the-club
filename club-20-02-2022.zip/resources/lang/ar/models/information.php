<?php

return array (
  'singular' => 'المعلومة',
  'plural' => 'المعلومات',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'name' => 'الاسم',
    'value' => 'القيمة',
    'status' => 'الحالة',
  ),
);
