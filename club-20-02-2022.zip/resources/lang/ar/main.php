<?php

return array(
  'profile' => 'الصفحة الشخصية',
  'settings' => 'الاعدادات',


);
