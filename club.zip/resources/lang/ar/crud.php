<?php

return [

    'add_new'      => 'اضافة جديد',
    'cancel'       => 'الغاء',
    'save'         => 'حفظ',
    'edit'         => 'تعديل',
    'detail'       => 'تفاصيل',
    'back'         => 'رجوع',
    'action'       => 'التحكم',
    'id'           => 'Id',
    'created_at'   => 'وقت الانشاء',
    'updated_at'   => 'وقت التعديل',
    'deleted_at'   => 'وقت الحذف',
    'are_you_sure' => 'هل انت متاكد؟',
];
