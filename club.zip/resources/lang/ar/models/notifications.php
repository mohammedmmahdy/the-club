<?php

return array (
  'singular' => 'اشعار',
  'plural' => 'الاشعارات',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'title' => 'العنوان',
    'body' => 'المحتوي',
    'send_to' => 'ارسال الي',
    'created_by' => 'انشاء بواسطة',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
