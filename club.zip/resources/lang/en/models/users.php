<?php

return array(
    'singular' => 'User',
    'plural' => 'Users',
    'fields' =>
    array(
        'id' => 'ID',
        'member_id' => 'Member ID',
        'email' => 'Email',
        'phone' => 'Phone',
        'name' => 'Name',
        'first_name' => 'First Name',
        'last_name' => 'Last Name',
        'social_status' => 'Social Status',
        'num_of_children' => 'Number Of Children',
        'status' => 'Status',
        'created_at' => 'Registered At',
        'updated_at' => 'Updated At',

    ),
);
