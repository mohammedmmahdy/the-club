<?php

return array (
  'singular' => 'Onboarding',
  'plural' => 'Onboardings',
  'fields' => 
  array (
    'id' => 'Id',
    'text' => 'Text',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
