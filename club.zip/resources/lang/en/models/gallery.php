<?php

return array (
  'singular' => 'Gallery',
  'plural' => 'Gallery',
  'fields' =>
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
