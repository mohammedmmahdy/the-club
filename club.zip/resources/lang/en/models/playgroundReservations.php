<?php

return array (
  'singular' => 'Playground Reservation',
  'plural' => 'Playground Reservations',
  'fields' =>
  array (
    'id' => 'Id',
    'playground_id' => 'Playground',
    'date' => 'Date',
    'time' => 'Time',
    'number_of_hours' => 'Number Of Hours',
    'number_of_people' => 'Number Of People',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
