<?php

return array(
    'singular'  => 'Option',
    'plural'    => 'Options',
    'fields'    =>
    array(
        'id'                                => 'Id',
        'created_at'                        => 'Created At',
        'updated_at'                        => 'Updated At',
        'logo'                              => 'Logo',
        'fav_icon'                          => 'Fav Icon',
        'wifi_name'                         => 'WiFi Name',
        'wifi_password'                     => 'WiFi Password',
        'safety_ratio'                      => 'Safety Ratio',
        'intro_video_link'                  => 'Web Intro Video Link',
    ),
);
