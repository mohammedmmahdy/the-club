<?php

return array (
  'singular' => 'Offer',
  'plural' => 'Offers',
  'fields' =>
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'description' => 'Description',
    'title' => 'Title',
    'brief' => 'Brief',
    'discount_value' => 'Discount Value',
    'offer_category_id' => 'Offer Category',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
