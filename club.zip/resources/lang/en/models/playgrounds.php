<?php

return array (
  'singular' => 'Playground',
  'plural' => 'Playgrounds',
  'fields' =>
  array (
    'id' => 'Id',
    'type_id' => 'Playground Type',
    'name' => 'Name',
    'price' => 'Price',
    'description' => 'Description',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
