<?php

return array (
  'singular' => 'Event Category',
  'plural' => 'Event Categories',
  'fields' =>
  array (
    'id' => 'Id',
    'name' => 'Name',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
