<?php

return array (
  'singular' => 'Branch',
  'plural' => 'Branches',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'address' => 'Address',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
