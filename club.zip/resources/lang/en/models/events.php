<?php

return array (
  'singular' => 'Event',
  'plural' => 'Events',
  'fields' =>
  array (
    'id' => 'Id',
    'title' => 'Title',
    'description' => 'Description',
    'date' => 'Date',
    'photo' => 'Photo',
    'icon' => 'Icon',
    'members_only' => 'Members Only',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
