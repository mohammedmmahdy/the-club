<?php

return array(
    'singular' => 'Slider',
    'plural' => 'Sliders',
    'fields' =>
    array(
        'id' => 'ID',
        'photo' => 'Photo',
        'title' => 'Title',
        'subtitle' => 'Subtitle',
        'content' => 'Content',
        'description' => 'Description',
        'button_text' => 'Button Text',
        'link' => 'Link',
        'video_link' => 'Video Link',
        'status' => 'Status',
        'sort' => 'Sort',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
