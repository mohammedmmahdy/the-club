<?php

return array(
    'singular' => 'Faq',
    'plural' => 'Faqs',
    'fields' =>
    array(
        'id' => 'ID',
        'action' => 'Action',
        'name' => 'Name',
        'question' => 'Question',
        'answer' => 'Answer',


        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
