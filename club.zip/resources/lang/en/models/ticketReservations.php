<?php

return array (
  'singular' => 'Ticket Reservation',
  'plural' => 'Ticket Reservations',
  'fields' =>
  array (
    'id' => 'Id',
    'user_id' => 'User',
    'date' => 'Date',
    'price' => 'Price',
    'name' => 'Name',
    'phone' => 'phone',
    'number_of_people' => 'Number Of People',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
